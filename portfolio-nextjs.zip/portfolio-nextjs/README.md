# Cess — Portfolio

Built with Next.js (App Router) and Tailwind CSS, set in Inter.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Before you deploy

Fill in the placeholders:
- `app/page.tsx` — GitHub / LinkedIn / email links in the sidebar and contact section
- `lib/data.ts` — job dates, and the two placeholder entries in `projects`

## Deploy with Vercel

1. Push this project to a GitHub repo.
2. Go to https://vercel.com/, import the repo, and accept the default Next.js build settings.
3. Vercel builds and deploys automatically on every push to `main`.

Or from the CLI:

```bash
npm i -g vercel
vercel
```
